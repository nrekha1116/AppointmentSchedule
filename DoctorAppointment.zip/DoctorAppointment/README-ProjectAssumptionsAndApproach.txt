

### Problem statement

We would like to build a simple service for managing doctors and their schedules.
Requirements:

* For each doctor we would initially like to store the following:
    * id
	* name
	* locations - represented as a collection of address strings
	* schedule - weekly schedule indicating the hours they are available each day of the week
* CRUD operations for doctors 
    - Plese refer Doctors Controller file
    - api/appointment/Doctors (Please refer AppointmentController Class file)
* Ability to book an appointment with a doctor (a tuple of (doctor, location, time))
    - api/appointment/NewAppointment (Please refer AppointmentController Class file)
* Ability to get all appointments for a doctor 
    - api/appointment/DoctorAppointments/{id} (Please refer AppointmentController Class file)
* Ability to cancel an appointment with a doctor
    - api/appointment/CancelAppointment/{id} (Please refer AppointmentController Class file)

Rekha Comments:

Attached project built in Visual Studio using C# langguage with all the requirements mentioned above.
and I Built two models one for Doctors and one for Appointments scheduling and canceling.
and you would see controllers under the path DoctorsAppoinment/Doctorsappoinment/Controllers and models under the path DoctorsAppoinment/Doctorsappoinment/models.


* Ability to book an appointment with a doctor (a tuple of (doctor, location, time))
Rekha Comments:assuming user would select the doctor from doctors list. Load locations based on the selected doctor. User enters his information and picks a date and available time (assuming the program shows only the availble timings of the selected doctor). API logic will take care if the patient is  new or existing, If it new it would create new patient in patient table and then and create an entry in apoointmentsschedule table for blocking the appoinment for that patient.
* Ability to get all appointments for a doctor
     Assuming user will select Doctor fom the doctor list.
* Ability to cancel an appointment with a doctor
    assuming user would select the doctor from the doctor list to cancel the appoinments.



#### Extra questions ####

Below are a few questions which expand the scope of the service. Please pick one and describe your approach.

* What are some real-world constraints to booking appointments that would add complexity to this API and how would they impact the design.
Rekha Comments: 
            - Network traffice accessing the api. Need to take care of Performance and scalibity and site realiability. 
            - Making sure the api is accessible at all time and have proper monitoring tools to ensure the api is up and running.
            - Mutiple users book the appoinments at the same time, Which would cause deadlocks, To avoid that we need to use locking functionality at Database to see the accurate details and avoid loss updates. (Concurrency issues)
            - Performance issues while fetching the data from source, we should try indexing database table columns as narrow as possible,avoid cursors and should avoid dependencies and use multi tasking methods to get the faster response.
                
                
* How would our design change if this API was opened up to external users?
Rekha Comments:
    - Making sure web api is secured with server certificates (https) and built in http protocal.
    - Ability to make sure the api is accessible in mobile,javascript,windows for satisfying the broad range of clients.
    - Dependancy injection and Ioc pricinples need to be incorporated (best practices)
    - Taking care of cross site scripting where attacker injects malicious code while access web api and to enable anto-forgerytoken menthod or any other security implementations
     - Authenticaiton and authorization and session timeouts (for better security)
     - Incorporate and implement logic to avoid SQL injection attacks and make sure the communication with database is performed with safe sql statements 
      - Perform penetrating tests on the server atleast once a month
            
            
            
* What concerns are there with multi-tenant data management and how could we modify the design to increase data security?
Rekha Comments: The main issue with multi-tenant is security risk due to sharing the data,
                we could normalize the database tables and maintain all personal and secured information in seperate tables and use encryption,decryption techniques while saving and fetching the data.
                - Incorporate and implement logic to avoid SQL injection attacks and make sure the communication with database is performed with safe sql statements 
                - Have the database is completely encrypted to avoid improper database backup access 
                - Have column level encryptions so that the personally identifiable information (sensitive data) is masked
                - Classify the database and mark the columns with appropriated classification information to have metadata stored about any changes to the particular column
                - Disable default sql logins (sa logins) and replace with service account logins
                - Make sure to have routine maintainance jobs on the sql server to backups and cleanup jobs and have proper data restoring points
                - Perform penetrating tests on the server atleast once a month
            


#### Database Schema and Data ####

* Please refer to DatabaseSchemaAndData.txt file
