namespace AppointmentSetup.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Appointment")]
    public partial class Appointment
    {
        public int Id { get; set; }

        public int Patient_Id { get; set; }

        public DateTime Start_Time { get; set; }

        public DateTime End_Time { get; set; }

        public int Doctor_Id { get; set; }

        public int Location_Id { get; set; }

        public virtual Doctor Doctor { get; set; }

        public virtual Location Location { get; set; }

        public virtual Patient Patient { get; set; }
    }
}
