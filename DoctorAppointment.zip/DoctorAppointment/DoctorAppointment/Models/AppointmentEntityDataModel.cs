namespace DoctorAppointment.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class AppointmentEntityDataModel : DbContext
    {
        public AppointmentEntityDataModel()
            : base("name=AppointmentEntityDataModel")
        {
            this.Configuration.LazyLoadingEnabled = false;
        }

        public virtual DbSet<Appointment> Appointments { get; set; }
        public virtual DbSet<Doctor_Locations> Doctor_Locations { get; set; }
        public virtual DbSet<Doctor> Doctors { get; set; }
        public virtual DbSet<Location> Locations { get; set; }
        public virtual DbSet<Patient> Patients { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Doctor>()
                .Property(e => e.First_Name)
                .IsUnicode(false);

            modelBuilder.Entity<Doctor>()
                .Property(e => e.Last_Name)
                .IsUnicode(false);

            modelBuilder.Entity<Doctor>()
                .HasMany(e => e.Appointments)
                .WithRequired(e => e.Doctor)
                .HasForeignKey(e => e.Doctor_Id)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Doctor>()
                .HasMany(e => e.Doctor_Locations)
                .WithRequired(e => e.Doctor)
                .HasForeignKey(e => e.Doctor_Id)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Location>()
                .Property(e => e.Address)
                .IsUnicode(false);

            modelBuilder.Entity<Location>()
                .HasMany(e => e.Appointments)
                .WithRequired(e => e.Location)
                .HasForeignKey(e => e.Location_Id)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Location>()
                .HasMany(e => e.Doctor_Locations)
                .WithRequired(e => e.Location)
                .HasForeignKey(e => e.Location_Id)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Patient>()
                .Property(e => e.First_Name)
                .IsUnicode(false);

            modelBuilder.Entity<Patient>()
                .Property(e => e.Last_Name)
                .IsUnicode(false);

            modelBuilder.Entity<Patient>()
                .HasMany(e => e.Appointments)
                .WithRequired(e => e.Patient)
                .HasForeignKey(e => e.Patient_Id)
                .WillCascadeOnDelete(false);
        }
    }
}
