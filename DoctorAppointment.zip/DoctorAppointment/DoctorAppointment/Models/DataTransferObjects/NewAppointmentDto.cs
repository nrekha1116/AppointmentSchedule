﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DoctorAppointment.Models.DataTransferObjects
{
    public class NewAppointmentDto
    {
        [Required]
        public string PatientFirstName { get; set; }
        public string PatientLastName { get; set; }
        public int DoctorId { get; set; }
        public int LocationId { get; set; }
        [Required]
        public string AppointmentDate { get; set; }
        [Required]
        public string AppointmentTime { get; set; }
    }

    public class DoctorsAndLocationsDto
    {
        public int DoctorId { get; set; }
        public string DoctorName { get; set; }
        public List<DoctorLocation> DoctorLocations { get; set; }
    }

    public class DoctorLocation
    {
        public int LocationId { get; set; }
        public string LocationAddress { get; set; }
    }
}