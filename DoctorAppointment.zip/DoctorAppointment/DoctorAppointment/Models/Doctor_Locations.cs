namespace DoctorAppointment.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Doctor_Locations
    {
        public int Id { get; set; }

        public int Doctor_Id { get; set; }

        public int Location_Id { get; set; }

        public virtual Doctor Doctor { get; set; }

        public virtual Location Location { get; set; }
    }
}
