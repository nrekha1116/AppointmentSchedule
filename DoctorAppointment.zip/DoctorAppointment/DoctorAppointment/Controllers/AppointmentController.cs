﻿using AppointmentSetup.Models;
using AppointmentSetup.Models.DataTransferObjects;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.Http;

namespace AppointmentSetup.Controllers
{
    public class AppointmentController : ApiController
    {
        private AppointmentEntityDataModel db = new AppointmentEntityDataModel();

        private object SerializeContent(object content)
        {
            return JsonConvert.SerializeObject(content, new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
            });
        }

        [HttpGet]
        [Route("api/appointment/Doctors")]
        public IHttpActionResult GetAllDoctors()
        {
            var doctors = db.Doctors.Include("Doctor_Locations").Where(x => x.IsActive == true).ToList();
            List<DoctorsAndLocationsDto> doctorsAndLocationsDtos = new List<DoctorsAndLocationsDto>();
            foreach(var doctor in doctors)
            {
                DoctorsAndLocationsDto doctorsAndLocationsDto = new DoctorsAndLocationsDto();
                doctorsAndLocationsDto.DoctorId = doctor.Id;
                doctorsAndLocationsDto.DoctorName = $"{doctor.First_Name}, {doctor.Last_Name}";
                doctorsAndLocationsDto.DoctorLocations = new List<DoctorLocation>();
                foreach (var location in doctor.Doctor_Locations)
                {
                    var doctLocation = db.Locations.Find(location.Location_Id);
                    doctorsAndLocationsDto.DoctorLocations.Add(new DoctorLocation() { LocationId  = location.Location_Id, LocationAddress = doctLocation.Address });
                }
                doctorsAndLocationsDtos.Add(doctorsAndLocationsDto);
            }
            var returnDoctors = new List<Doctor>();

            if (doctorsAndLocationsDtos == null)
            {
                return NotFound();
            }
            return Ok(SerializeContent(doctorsAndLocationsDtos));
        }

        [HttpGet]
        [Route("api/appointment/DoctorAppointments/{id}")]
        public IHttpActionResult GetAllAppointments(int id)
        {

            var appointments = db.Appointments.Where(x => x.Doctor_Id == id).ToList();

            DoctorAppointmentsDto doctorAppointments = new DoctorAppointmentsDto();
            doctorAppointments.PatientAppointments = new List<PatientAppointmentsDto>();

            foreach (var appointment in appointments)
            {
                doctorAppointments.AppointmentId = appointment.Id;
                doctorAppointments.DoctorName = $"{appointment.Doctor.First_Name}, {appointment.Doctor.Last_Name}";
                doctorAppointments.PatientAppointments.Add(new PatientAppointmentsDto()
                {
                    PatientName = $"{appointment.Patient.First_Name}, {appointment.Patient.Last_Name}",
                    Location = appointment.Location.Address,
                    StartTime = appointment.Start_Time.ToShortDateString(),
                    EndTime = appointment.End_Time.ToShortDateString()
                });
            }

            if (doctorAppointments == null)
            {
                return NotFound();
            }
            return Ok(SerializeContent(doctorAppointments));
        }

        [HttpDelete]
        [Route("api/appointment/CancelAppointment/{id}")]
        public IHttpActionResult Cancel(int id)
        {
            Appointment appointmentObj = db.Appointments.Find(id);
            if (appointmentObj == null)
            {
                return NotFound();
            }
            db.Appointments.Remove(appointmentObj);
            db.SaveChanges();
            return Ok(SerializeContent(appointmentObj));
        }

        [HttpPost]
        [Route("api/appointment/NewAppointment")]
        public IHttpActionResult CreateAppointment([FromBody] NewAppointmentDto newAppointmentDto)
        {
            Appointment appointmentObj = new Appointment();
            var patientId = 0;
            if (ModelState.IsValid)
            {
                var patientInfo = db.Patients.Where(x => x.First_Name == newAppointmentDto.PatientFirstName && x.Last_Name == newAppointmentDto.PatientLastName).SingleOrDefault();
                if (patientInfo != null)
                {
                    patientId = patientInfo.Id;
                }
                else
                {
                    Patient patientObj = new Patient()
                    {
                        First_Name = newAppointmentDto.PatientFirstName,
                        Last_Name = newAppointmentDto.PatientLastName
                    };

                    db.Patients.Add(patientObj);
                    int id = patientObj.Id;
                    patientId = id;
                }

                appointmentObj.Patient_Id = patientId;
                appointmentObj.Doctor_Id = newAppointmentDto.DoctorId;
                appointmentObj.Location_Id = newAppointmentDto.LocationId;
                var selectedAppDate = Convert.ToDateTime(newAppointmentDto.AppointmentDate, CultureInfo.InvariantCulture);
                var selectedAppTime = selectedAppDate.Add(TimeSpan.Parse(newAppointmentDto.AppointmentTime));
                appointmentObj.Start_Time = selectedAppTime;
                appointmentObj.End_Time = selectedAppTime.AddHours(1);

                db.Appointments.Add(appointmentObj);
                db.SaveChanges();
                return Ok(SerializeContent(appointmentObj));
            }
            else
            {
                //Handle invalid model state 
               // report to the user with a meningful message and navigate back to home screen 
            }
            return null;
        }
    }
}
